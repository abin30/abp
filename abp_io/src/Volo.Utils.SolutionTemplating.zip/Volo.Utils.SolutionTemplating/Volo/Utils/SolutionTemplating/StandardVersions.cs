﻿namespace Volo.Utils.SolutionTemplating
{
    public static class StandardVersions
    {
        public const string LatestStable = "LatestStable";

        public const string LatestUnstable = "LatestUnstable";
    }
}

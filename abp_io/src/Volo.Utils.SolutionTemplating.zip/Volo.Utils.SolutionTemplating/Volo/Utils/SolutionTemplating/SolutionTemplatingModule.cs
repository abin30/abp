﻿using Volo.Abp.Domain;
using Volo.Abp.Modularity;

namespace Volo.Utils.SolutionTemplating
{
    [DependsOn(typeof(AbpDddDomainModule))]
    public class SolutionTemplatingModule : AbpModule
    {
        
    }
}

﻿namespace Volo.Utils.SolutionTemplating.Building
{
    public class ProjectResult
    {
        public byte[] ZipContent { get; set; }
    }
}
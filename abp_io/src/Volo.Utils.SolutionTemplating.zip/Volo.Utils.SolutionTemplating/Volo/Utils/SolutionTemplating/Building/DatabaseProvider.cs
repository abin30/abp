﻿namespace Volo.Utils.SolutionTemplating.Building
{
    public enum DatabaseProvider : byte
    {
        Irrelevant = 0,
        EntityFrameworkCore = 1,
        MongoDb = 2
    }
}